/**
 * @description This file contains DB operations for scenarios table API
 *
 * Uses Prisma ORM client wrapper (prismaORM/index) similar to editDefaultConfig.
 *
 * IMPORTANT:
 * - We intentionally use rdb.$queryRaw (NOT $queryRawUnsafe) so values are parameter-bound.
 * - The table name is a constant and is not user-controlled.
 */
const { dbConnect, dbDisconnect } = require("prismaORM/index");
const { DB_CLOSE_CONNECTION_STMT } = require("constants/customConstants");

// NOTE:
// The workflow doc queries "supply_planning.scenarios". If your actual DB uses a different table name,
// update these SQL statements accordingly.
const ORDER_COL = "created_date_timestamp";

/**
 * @description Function to get total scenario count (active only) with optional plan filter
 * @param {string[]|null} planTypeFilter - e.g., ["getsudo"] or null for all
 * @returns {number} count
 */
async function getScenarioCount(planTypeFilter) {
  const rdb = await dbConnect();
  try {
    // If you later need multiple plan types, convert this to `IN (...)` using Prisma.sql helpers.
    if (Array.isArray(planTypeFilter) && planTypeFilter.length > 0) {
      const planType = planTypeFilter[0];
      const rows =
        await rdb.$queryRaw`SELECT COUNT(*)::int AS count FROM supply_planning.scenarios WHERE is_active = true AND plan_type = ${planType};`;
      return rows?.[0]?.count ?? 0;
    }

    const rows =
      await rdb.$queryRaw`SELECT COUNT(*)::int AS count FROM supply_planning.scenarios WHERE is_active = true;`;
    return rows?.[0]?.count ?? 0;
  } finally {
    await dbDisconnect(rdb, DB_CLOSE_CONNECTION_STMT);
  }
}

/**
 * @description Function to fetch scenario list (active only) with pagination and optional plan filter
 * @param {number} limit
 * @param {number} startAt
 * @param {string[]|null} planTypeFilter
 * @returns {Array<Object>} rows
 */
async function getScenarioPage(limit, startAt, planTypeFilter) {
  const rdb = await dbConnect();
  try {
    if (Array.isArray(planTypeFilter) && planTypeFilter.length > 0) {
      const planType = planTypeFilter[0];
      // ORDER BY column is constant; values are parameter-bound.
      const rows =
        await rdb.$queryRaw`SELECT * FROM supply_planning.scenarios WHERE is_active = true AND plan_type = ${planType} ORDER BY created_date_timestamp DESC LIMIT ${limit} OFFSET ${startAt};`;
      return rows || [];
    }

    const rows =
      await rdb.$queryRaw`SELECT * FROM supply_planning.scenarios WHERE is_active = true ORDER BY created_date_timestamp DESC LIMIT ${limit} OFFSET ${startAt};`;
    return rows || [];
  } finally {
    await dbDisconnect(rdb, DB_CLOSE_CONNECTION_STMT);
  }
}

module.exports = {
  getScenarioCount,
  getScenarioPage,
  ORDER_COL,
};
