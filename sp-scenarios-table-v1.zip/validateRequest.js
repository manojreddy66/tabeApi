/**
 * This file contains input request validation
 */
const { getValidationSchema } = require("schemaValidator/supplyPlanning/scenarios/scenariosTableSchema");

/**
 * @description Function to validate input request
 * @param {Object} params: { type, page, limit }
 * @returns {Object} errorMessages: List of validation error messages
 *          normalizedParams: parsed + normalized values used by service/db
 */
async function validateInput(params) {
  const errorMessages = [];

  await validateParams(params, errorMessages);

  // Normalize only if schema validation passed
  const normalizedParams =
    errorMessages.length === 0 ? normalizeParams(params) : null;

  return {
    errorMessages: [...new Set(errorMessages)],
    normalizedParams,
  };
}

/**
 * @description Joi validation (abortEarly false for multiple errors)
 */
async function validateParams(params, errorMessages) {
  const options = { abortEarly: false };
  const schema = await getValidationSchema();
  const { error } = await schema.validate(params, options);

  if (error) {
    error.details.forEach((detail) => errorMessages.push(detail.message));
  }
}

/**
 * @description Normalize/derive values for DB usage.
 * - perPageRow = limit
 * - startAt = (page - 1) * perPageRow
 * - planTypeFilter: null for all, else ["getsudo"]
 */
function normalizeParams(params) {
  const type = String(params.type).toLowerCase();
  const page = Number(params.page);
  const limit = Number(params.limit);

  // For All tab, we don't filter on plan_type.
  // For Getsudo tab, filter getsudo rows.
  const planTypeFilter = type === "getsudo" ? ["getsudo"] : null;

  return { type, page, limit, planTypeFilter };
}

module.exports = { validateInput };
