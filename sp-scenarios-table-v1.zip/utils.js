/**
 * @description this file contain scenarios table common utils
 */
const { format } = require("date-fns");

/**
 * @description Function to prepare response for scenarios table API.
 * @param {Object} params
 * @param {number} params.page
 * @param {number} params.limit
 * @param {number} params.totalRecords
 * @param {Array} params.rows
 * @returns {Object} response formatted for UI
 */
function prepareResponse({ page, limit, totalRecords, rows }) {
  const totalPage = limit > 0 ? Math.ceil(totalRecords / limit) : 0;

  return {
    currentPage: page,
    recordsPerPage: limit,
    totalRecords,
    totalPage,
    data: (rows || []).map(mapScenarioRowToUi),
  };
}

/**
 * @description Map DB row to UI response shape
 * Expected UI keys from workflow doc:
 *  scenario, scenarioId, plan, namc, Line, cycle, createdBy, lastUpdated, status
 */
function mapScenarioRowToUi(row) {
  const planType = String(row.plan_type || "").toLowerCase();
  const plan = planType === "ap" ? "AP" : planType === "getsudo" ? "Getsudo" : row.plan_type;

  const lastUpdated = row.last_updated || row.lastUpdated || row.last_updated_timestamp || row.created_date_timestamp;
  return {
    scenario: row.scenario_name,
    scenarioId: row.scenario_id,
    plan,
    namc: row.namc,
    Line: row.line, // Keeping 'Line' key as in sample response
    cycle: row.scenario_cycle,
    createdBy: row.user_name,
    lastUpdated: lastUpdated ? format(new Date(lastUpdated), "MM/dd/yyyy") : null,
    status: row.scenario_status,
  };
}

module.exports = { prepareResponse };
