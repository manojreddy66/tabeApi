/**
 * @description This file contains routing to input validation, DB operations and prepare response
 */
const { BadRequest } = require("utils/api_response_utils");
const { validateInput } = require("./validateRequest");
const { getScenarioCount, getScenarioPage } = require("./scenariosTableDb");
const { prepareResponse } = require("./utils");

/**
 * @description Function to validate & return scenario table data.
 * @param {Object} event: API request
 * @returns {Object} response - scenarios table response
 */
async function getScenariosTable(event) {
  try {
    const type = event?.pathParameters?.type;
    const queryParams = event?.queryStringParameters || {};

    // NOTE: API Gateway sends query params as strings. Normalize to number.
    const params = {
      type,
      page: queryParams.page !== undefined ? Number(queryParams.page) : queryParams.page,
      limit: queryParams.limit !== undefined ? Number(queryParams.limit) : queryParams.limit,
    };

    const { errorMessages, normalizedParams } = await validateInput(params);

    if (errorMessages.length > 0) {
      throw new BadRequest(errorMessages);
    }

    const { page, limit, planTypeFilter } = normalizedParams;

    // Fetch count + page data in parallel
    const [countRow, rows] = await Promise.all([
      getScenarioCount(planTypeFilter),
      getScenarioPage(planTypeFilter, page, limit),
    ]);

    const totalRecords = Number(countRow?.count ?? 0);
    return prepareResponse({ page, limit, totalRecords, rows });
  } catch (err) {
    console.log("Error in getScenariosTable:", err);
    throw err;
  }
}

module.exports = { getScenariosTable };
