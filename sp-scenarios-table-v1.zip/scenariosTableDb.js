/**
 * @description This file contains DB operations for scenarios table API
 *
 * Uses Prisma ORM client wrapper (prismaORM/index) similar to editDefaultConfig.
 */
const { dbConnect, dbDisconnect } = require("prismaORM/index");
const { DB_CLOSE_CONNECTION_STMT } = require("constants/customConstants");

// NOTE:
// The schema PDF shows table name "supply_planning.scenario" (singular) in create statement,
// but other parts mention "supply_planning.scenarios". Using scenarios per API workflow doc.
// If your actual DB uses the singular table name, update TABLE below.
const TABLE = "supply_planning.scenarios";

/**
 * @description Function to get total scenario count (active only) with optional plan filter
 * @param {string[]|null} planTypeFilter - e.g., ["getsudo"] or null for all
 * @returns {Object} { count: <number string> }
 */
async function getScenarioCount(planTypeFilter) {
  const rdb = await dbConnect();
  try {
    if (Array.isArray(planTypeFilter) && planTypeFilter.length > 0) {
      const rows = await rdb.$queryRawUnsafe(
        `select count(*) as count from ${TABLE} where is_active = true and plan_type in (${planTypeFilter
          .map((v) => `'${v}'`)
          .join(",")});`,
      );
      return rows?.[0];
    }

    const rows = await rdb.$queryRawUnsafe(
      `select count(*) as count from ${TABLE} where is_active = true;`,
    );
    return rows?.[0];
  } catch (err) {
    console.log("Error in getScenarioCount:", err);
    throw err;
  } finally {
    dbDisconnect();
    console.log(DB_CLOSE_CONNECTION_STMT);
  }
}

/**
 * @description Function to get paginated scenario rows (active only)
 * @param {string[]|null} planTypeFilter
 * @param {number} page
 * @param {number} limit
 * @returns {Array} scenario rows
 */
async function getScenarioPage(planTypeFilter, page, limit) {
  const rdb = await dbConnect();
  try {
    const perPageRow = limit;
    const startAt = (page - 1) * perPageRow;

    const planFilterSql =
      Array.isArray(planTypeFilter) && planTypeFilter.length > 0
        ? ` and plan_type in (${planTypeFilter.map((v) => `'${v}'`).join(",")})`
        : "";

    // Ordering: workflow doc says "order by created_date desc"
    // Schema uses "created_date_timestamp". If your column name differs, update ORDER_COL.
    const ORDER_COL = "created_date_timestamp";

    const query = `
      select *
      from ${TABLE}
      where is_active = true
      ${planFilterSql}
      order by ${ORDER_COL} desc
      limit ${perPageRow} offset ${startAt};
    `;

    const rows = await rdb.$queryRawUnsafe(query);
    return rows || [];
  } catch (err) {
    console.log("Error in getScenarioPage:", err);
    throw err;
  } finally {
    dbDisconnect();
    console.log(DB_CLOSE_CONNECTION_STMT);
  }
}

module.exports = { getScenarioCount, getScenarioPage };
